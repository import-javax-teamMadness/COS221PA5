<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Media</title>
    <link rel="stylesheet" href="CSS/manageUsers-styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
<div class="nav">
		<a href="eventPage.php">Events</a>
		<a href="playersPage.php">Players</a>
        <a href="manageUsers.php">Manage Users</a>
        <a href="captureScores.php">Capture Scores</a>
        <a class="active" href="uploadMedia.php">Upload Media</a>
        
	</div>
</br>


    <div>
    <a href="#"  id= "viewing" class="btn">View Media</a>
    <a href="#" id= "adding" class="btn">Upload Media</a>
    

    </div>


   


   
</body>
</html>
