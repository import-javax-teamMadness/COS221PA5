<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="CSS/addplayers.css">
</head>
<body>
<div class="nav">
		<a href="eventPage.php">Events</a>
		<a class="active" href="playersPage.php">Players</a>
        <a href="manageUsers.php">Manage Users</a>
        <a href="captureScores.php">Capture Scores</a>
        <a href="uploadMedia.php">Upload Media</a>
	</div>
</br>

    <form method="post" id="addPlayer" action="playersPage.php">
        <label>Player ID:</label>
        <input type="text" id="player_id" name="id" readonly="readonly"></br></br>
        <label>First Name:</label>
        <input type="text" id="fname" name="fname"></br></br>
        <label>Last Name:</label>
        <input type="text" id="lname" name="lname"></br></br>
        <label>Gender:</label>
        <input type="text" id="gender" name="gender"></br></br>
        <label>Birthday:</label>
        <input type="text" id="bday" name="bday" placeholder="dd-mm-yyy"></br></br>
        <label>Handicap:</label>
        <input type="text" id="handicap" name="handicap"></br></br>
        <button>Insert Player</button>
    </form>

<?php
        $servername = '127.0.0.1';
        $username = 'root'; 
        $password = 'K3yboard2609!';
        $conn = new mysqli($servername, $username, $password);

        if($conn->connect_error) 
        {
            die('Connection failed: ' . $conn->connect_error);
        }  
        else 
        {
            $conn->select_db("newd");
            echo "<script>console.log('Database connected Successfully')</script>";
        }

        $query = "Select MAX(id) as MaxID from persons";
        $result = mysqli_query($conn, $query);
        $row = $result->fetch_assoc();
        $id = $row['MaxID'] + 1;

        echo "<script>
                var textField = document.getElementById('player_id');
                textField.value = '" . $id . "';
              </script>";
        
        if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['gender']) && isset($_POST['bday']))
        {
            $query = "Insert INTO persons(id, person_key, publisher_id, gender, birth_date, death_date, birth_location_id, hometown_location_id, residence_location_id, death_location_id) 
                      Values(" . $_POST['id'] . ", null, null, '" . $_POST['gender'] . "', '" . $_POST['bday'] . "', null, null, null, null, null)";
                      
            $query2 = "Insert INTO golf_player(id, events_won, world_ranking, handicap, player_fname, player_sname) 
                      Values(" . $_POST['id'] . ", 0, -1, '" . $_POST['handicap'] . "', '" . $_POST['fname'] . "', '" . $_POST['lname'] . "')";

            $result = mysqli_query($conn, $query);
            $result2 = mysqli_query($conn, $query2);
            if($result == TRUE && $result2 == TRUE)
            {
                $conn->close();
                $_POST = array();
                echo "<script>document.getElementById('addPlayer').action = 'playersPage.php';</script>";
                echo "<script>alert('Player Added')</script>";
            }
            else
            {
                echo "<script>alert('Please enter valid data')</script>";
                echo "<script>document.getElementById('addPlayer').action = 'addPlayer.php';</script>";
                $_POST = array();
            }
        }

        $_POST = array();
?>

</body>
</html>