<?php
$servername = '127.0.0.1';
$username = 'root'; 
$password = 'K3yboard2609!';

$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
} else {
    $conn->select_db("newd");
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $query = "SELECT email, password FROM users WHERE email ='" . $_POST['username'] . "' AND password='" . $_POST['password'] . "'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        session_start();
        $_SESSION["login"] = true;
        $_SESSION["username"] = $_POST['username'];
        $conn->close();
        header("Location: eventPage.php");
    } else {
        echo '<span class="error-span" id="pass-error">Invalid username or password</span>';
    }
}