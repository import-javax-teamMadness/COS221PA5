<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="CSS/players.css">
    <script type="text/javascript" src="JS/getPlayer.js"></script>
</head>
<body>
    <div>
    <table style="margin: auto; background-color: white;" border = '3'; id='players'><th>ID</th><th>Player Name</th><th>Events Won</th><th>World Ranking</th><th>Handicap</th>

    <form method="post" action="playersPage.php">
        <input type="text" id="searchText" name="data">
        <button>Search</button>
    </form>
    </div>

    <?php
        $servername = 'wheatley.cs.up.ac.za';
        $username = 'u20431122'; 
        $password = 'E37VCXZWH5LZ3W6RCTHKYKJWSEDIT7DR';
        $conn = new mysqli($servername, $username, $password);

        if($conn->connect_error) 
        {
            die('Connection failed: ' . $conn->connect_error);
        }  
        else 
        {
            $conn->select_db("u20431122_");
            echo "<script>console.log('Database connected Successfully')</script>";
        }

        if(!isset($_POST['data']))
        {
            $query = "Select * from `golf_player`";
            $result = mysqli_query($conn, $query);
            $list = array();

            if(mysqli_num_rows($result) > 0)    
            {
                while($row = $result->fetch_assoc())
                {
                    echo "<script>var table = document.getElementById('players');
                        var row = table.insertRow();
                
                        var cell1 = row.insertCell(0);
                        var cell2 = row.insertCell(1);
                        var cell3 = row.insertCell(2);
                        var cell4 = row.insertCell(3);
                        var cell5 = row.insertCell(4);
                
                        cell1.innerHTML = ". $row['id'] .";
                        cell2.innerHTML = '". $row['player_fname'] . " " . $row['player_sname'] . "';
                        cell3.innerHTML = ". $row['events_won'] .";
                        cell4.innerHTML = ". $row['world_ranking'] .";
                        cell5.innerHTML = ". $row['handicap'] .";</script>";
                }
            }
            else
            {
                echo "No data available";
            }
            unset($_POST['data']);
        }
        else
        {
            $param = $_POST['data'];
            $query = "Select * from `golf_player` where `player_fname` like '%" . $param . "%' OR `player_sname` like '%" . $param . "%'";
            $result = mysqli_query($conn, $query);
            $list = array();

            if(mysqli_num_rows($result) > 0)    
            {
                while($row = $result->fetch_assoc())
                {
                    echo "<script>var table = document.getElementById('players');
                        var row = table.insertRow();
                
                        var cell1 = row.insertCell(0);
                        var cell2 = row.insertCell(1);
                        var cell3 = row.insertCell(2);
                        var cell4 = row.insertCell(3);
                        var cell5 = row.insertCell(4);
                
                        cell1.innerHTML = ". $row['id'] .";
                        cell2.innerHTML = '". $row['player_fname'] . " " . $row['player_sname'] . "';
                        cell3.innerHTML = ". $row['events_won'] .";
                        cell4.innerHTML = ". $row['world_ranking'] .";
                        cell5.innerHTML = ". $row['handicap'] .";</script>";
                }
            }
            else
            {
                echo "No data available";
            }
        }

?>
</body>